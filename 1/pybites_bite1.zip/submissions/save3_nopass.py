def sum_numbers(numbers=None):
    if len(numbers)>=0:
            return sum(list(numbers))
    else:
        return sum(range(1,101))
        
